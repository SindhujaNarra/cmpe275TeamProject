package com.cmpe275.teamproject.DAO;

public interface UserDOA {

}
