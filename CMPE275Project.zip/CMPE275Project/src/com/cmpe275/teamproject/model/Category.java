package com.cmpe275.teamproject.model;

import javax.persistence.Enumerated;

public enum Category {
	Drink,
	Appetizer,
	Main_course,
	Desert;
}
